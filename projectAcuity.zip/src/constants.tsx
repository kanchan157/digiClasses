
export const BASE_API_URL = 'https://staging-acuityapi.digiryte.co.uk';

export const api_url = {
    login: 'auth/sign_in',
    submit_registration_request: 'submit_registration_request',
    password: 'auth/password',
    organisation: '/organisations'
};
