import React from 'react'

function OnboardingAdmin_Partner() {
    return (
        <div>
            OnboardingAdmin_Partner
        </div>
    )
}

export default OnboardingAdmin_Partner
