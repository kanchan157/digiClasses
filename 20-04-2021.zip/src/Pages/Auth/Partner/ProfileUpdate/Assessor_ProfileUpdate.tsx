import React from 'react'

function Assessor_ProfileUpdate() {
    return (
        <div>
            Assessor_ProfileUpdate
        </div>
    )
}

export default Assessor_ProfileUpdate
