import React from 'react'

function Facilitator_ProfileUpdate() {
    return (
        <div>
            Facilitator_ProfileUpdate
        </div>
    )
}

export default Facilitator_ProfileUpdate
