import React from 'react'

function Coach_ProfileUpdate() {
    return (
        <div>
            Coach_ProfileUpdate
        </div>
    )
}

export default Coach_ProfileUpdate
